package banking.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import banking.bean.BankAccount;
import banking.dao.BankAccountDaoImpl;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public class BankAccountServiceImpl implements BankAccountService {
	static BankAccountDaoImpl dao = new BankAccountDaoImpl();
	static List<BankAccount> list = new ArrayList<BankAccount>();
	BankAccount bean=new BankAccount();
	@Override
	public BankAccount CreateAccount(BankAccount account) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		return dao.CreateAccount(account);
	}
	@Override
	public double displayBalance(int accountNo) throws ClassNotFoundException, InvalidAccountException {
	      bean=dao.displayBalance(accountNo);
	      double balance = 0 ;
	      try {
			if(bean==null)
			  {
				throw new InvalidAccountException("Please enter valid account");
			  }
			  else
				 balance = bean.getInitialBalance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      return balance;
	}
	@Override
	public BankAccount deposit(int accountNo, double amount) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		 bean=dao.deposit(accountNo, amount);
		return bean;
	}
	@Override
	public BankAccount withdraw(int accountNo, double amount) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		bean=dao.withdraw(accountNo, amount);
		return bean;
	}
	@Override
	public BankAccount fundTransfer(int accountNo1, int accountNo2, double amount) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		return dao.fundTransfer(accountNo1, accountNo2, amount);
	}
	@Override
	public ArrayList printDetails(int accountNo) throws ClassNotFoundException, SQLException {
		return dao.printDetails(accountNo);
	}
	
}
	